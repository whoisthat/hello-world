// Code goes here
var todos= new Array("Buy some eggs", "Code Javascript", "Read a book");
var todoElement= document.getElementById("todoList");

var loadTodo= function(){
  todoElement.innerHTML="";
  for(var i=0; i<todos.length; i++){
    todoElement.innerHTML +=i+1+ ". " + todos[i] + "<br/>";
  }
};

var addTodo= function (){
  var todoItem=prompt ("What task do you want to do?");
  todos.push(todoItem);
  loadTodo();
};

var removeTodo= function(){
  var todoItemDone= prompt ("Select the item number you want to remove");
  todos.splice(todoItemDone-1,1);
  loadTodo();
  
}
loadTodo();




